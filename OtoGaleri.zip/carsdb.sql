-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 29 Ara 2023, 13:29:26
-- Sunucu sürümü: 10.4.28-MariaDB
-- PHP Sürümü: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `carsdb`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `cars`
--

CREATE TABLE `cars` (
  `ID` int(2) NOT NULL,
  `Marka` varchar(20) NOT NULL,
  `Model` varchar(20) NOT NULL,
  `Yıl` int(4) NOT NULL,
  `Fiyat` decimal(20,0) NOT NULL,
  `ImageURL` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `cars`
--

INSERT INTO `cars` (`ID`, `Marka`, `Model`, `Yıl`, `Fiyat`, `ImageURL`) VALUES
(1, 'Bmw', '', 0, 0, 'images/pic-1.png'),
(2, 'Mercedes', '', 0, 0, 'images/pic-2.png'),
(3, 'Camaro', '', 0, 0, 'images/pic-4.png'),
(4, 'Audi', '', 0, 0, 'images/pic-3.png'),
(5, 'Audi', 'A4', 2017, 1300000, 'images/audi-1.png'),
(6, 'Audi', 'A5', 2022, 2300000, 'images/audi-2.png'),
(7, 'Audi', 'Q5', 2019, 2000000, 'images/audi-3.png'),
(8, 'Camaro', 'ZL1', 2022, 17500000, 'images/camaro-1.png'),
(9, 'Camaro', 'SS', 2012, 4200000, 'images/camaro-2.png'),
(10, 'Camaro', '2LT', 2011, 2500000, 'images/camaro-3.png'),
(11, 'Mercedes-Benz', 'C200D', 2017, 1700000, 'images/mercedes-1.png'),
(12, 'Mercedes-Benz', 'E250', 2018, 2300000, 'images/mercedes-2.png'),
(13, 'Mercedes-Benz', 'CLS350', 2017, 3000000, 'images/mercedes-3.png'),
(14, 'Bmw', '320I ', 2017, 1500000, 'images/bmw-1.png'),
(15, 'Bmw', '520I', 2017, 1850000, 'images/bmw-2.png'),
(16, 'Bmw', 'X3', 2018, 1600000, 'images/bmw-3.png');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`ID`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `cars`
--
ALTER TABLE `cars`
  MODIFY `ID` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
