<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Titillium+Web:wght@400;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Titillium Web', sans-serif;
        }

        img.logo {
            width: 150px;
            height: auto;
            margin-top: 50px;
        }

        .navbar {
            height: 12%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-right: 30px;
        }

        p {
            color: white;
        }

        nav ul {
            list-style: none;
            display: flex;
            column-gap: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            transition: ease 0.5s;
        }

        nav ul li a:hover {
            color: #000;
        }

        .container {
            width: 100%;
            height: 100vh;
            padding-left: 8%;
            padding-right: 8%;
            background-image: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
                url(./images/Lovepik_com-500669163-science-and-technology-automobile-background.png);
            background-position: center;
            background-size: cover;
        }

        .row {
            display: flex;
            align-items: center;
            column-gap: 10px;
            height: 88%;
            justify-content: center;
            flex-direction: column;
        }

        .col {
            flex-basis: 50%;
        }

        h1 {
            color: #fff;
            font-size: 60px;
            margin-bottom: 50px;
        }

        .cards {
            max-width: 900px;
            margin: auto;
            text-align: center;
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
            justify-content: center;
        }

        .card {
            width: 270px;
            height: 220px;
            border-radius: 10px;
            padding: 5px 20px;
            cursor: pointer;
            background-position: center;
            background-size: cover;
            position: relative;
            transition: ease 0.5s;
            margin-bottom: 20px;
        }

        .card:hover {
            transform: translateY(-10px);
        }

        .card .card-head {
            background-color: rgb(0, 0, 0, 0.7);
            color: #fff;
            border-radius: 6px;
            padding: 6px;
            font-size: 16px;
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            margin: auto;
            width: 90%;
        }

        .about-rectangle {
            width: 100%;
            height: auto;
            background-color: rgba(0, 0, 0, 0.50);
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 15px;
            margin-bottom: 50px;
        }

        .about-text-container {
            max-width: 600px;
            text-align: center;
            border-radius: 15px;
            overflow: hidden;

        }

        .about-text {
            color: #000;
            font-size: 24px;
            padding: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="navbar">
            <a href="#">
                <img class="logo" src="./images/images.png" alt="logo">
            </a>
            <nav>
                <ul>
                    <li><a href="/proje/Home.php">HOME</a></li>
                    <li><a href="/proje/OurCars.php">OUR CARS</a></li>
                    <li><a href="/proje/About.php">ABOUT</a></li>
                    <li><a href="/proje/Contact.php">CONTACT</a></li>
                </ul>
            </nav>
        </div>
        <div class="row">
            <h1>Hakkımızda</h1>
            <div class="about-rectangle">
                <div class="about-text-container">
                    <div class="about-text">
                        <p>
                            Merhaba! Biz Gencturk Automative, oto galeri projemizle buradayız. Amacımız, müşterilere en
                            kaliteli ve güvenilir otomobil seçeneklerini sunmak, sürüş deneyimlerini zenginleştirmek ve
                            araç alım süreçlerini kolaylaştırmaktır.
                        </p>
                        <p>
                            Ekibimiz, otomobil tutkunlarından oluşuyor ve modern tasarım anlayışını benimseyerek
                            kullanıcı dostu bir deneyim sunmayı hedefliyor.
                        </p>
                        <p>
                            Sitemizdeki "Our Cars" bölümünde geniş bir otomobil koleksiyonunu keşfedin. Daha fazla bilgi
                            veya iletişim için "Contact" kısmını ziyaret edin. Keyifli sürüşler!
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
</body>

</html>