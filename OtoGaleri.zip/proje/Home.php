<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Cars Website</title>
    <link rel="stylesheet" href="/proje/style.css">
</head>

<body>
    <div class="container">
        <div class="navbar">
            <a href="#">
                <img src="./images/images.png" alt="logo">
            </a>
            <nav>
                <ul>
                    <li><a href="/proje/Home.php">HOME</a></li>
                    <li><a href="/proje/OurCars.php">OUR CARS</a></li>
                    <li><a href="/proje/About.php">ABOUT</a></li>
                    <li><a href="/proje/Contact.php">CONTACT</a></li>
                </ul>
            </nav>
        </div>
        <div class="row">
            <div class="col">
                <h1>GENCTURK WEBSITE
                    <hr>
                </h1>
                <ul>
                    <p class="desc">
                        Sizi otomobil tutkunuzla buluşturan çevrimiçi oto galerimizde, en güncel ve çeşitli otomobil
                        modellerini keşfedin. Her markadan, her segmentten araçları bir araya getirerek, sizin için
                        ideal otomobili bulmayı hedefliyoruz. Estetik tasarımlar, üstün performans ve teknoloji ile
                        donatılmış araçlarımızla sürüş keyfinizi en üst seviyeye çıkarın. Sitemizi ziyaret edin,
                        hayalinizdeki araca bir adım daha yaklaşın.
                    </p>
                </ul>
                <a href="/proje/OurCars.php" class="btn"
                    style="display: inline-block; padding: 12px 28px; font-size: 12px; font-weight: 700; color: #000; text-decoration: none; background-color: #fff; border-radius: 20px;">OUR
                    CARS</a>
            </div>
            <div class="col">
                <div class="cards">
                    <?php
                    $host = "localhost";
                    $kullanici = "root";
                    $sifre = "1234";
                    $veritabani = "carsdb";
                    $tablo = "cars";

                    $baglanti = mysqli_connect($host, $kullanici, $sifre);

                    if ($baglanti) {
                        // Veritabanını seç
                        mysqli_select_db($baglanti, $veritabani) or die("Veri Tabanına Bağlanılamadı");

                        // Belirli markalara ait verileri seç
                        $selectQuery = "SELECT DISTINCT Marka, ImageURL FROM $tablo WHERE ImageURL IN ('images/pic-1.png', 'images/pic-2.png', 'images/pic-3.png', 'images/pic-4.png')";
                        $result = mysqli_query($baglanti, $selectQuery);

                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo '<div class="card">';
                                echo '<div class="card-head">';
                                echo '<h5>' . $row['Marka'] . '</h5>';
                                echo '</div>';
                                echo '<div class="card-bottom">';

                                // Markaya özel kontrol
                                $marka = str_replace(' ', '_', $row['Marka']); // Boşlukları alt çizgi ile değiştir
                                $url = "/proje/{$marka}.php";

                                echo "<a href=\"$url\">";
                                echo '<img src="' . $row['ImageURL'] . '" alt="' . $row['Marka'] . '" class="card-img">';
                                echo '</a>';

                                echo '</div>';
                                echo '</div>';
                            }
                        } else {
                            echo "Veri çekme hatası: " . mysqli_error($baglanti);
                        }
                    } else {
                        echo "Bağlantı Sağlanamadı";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>