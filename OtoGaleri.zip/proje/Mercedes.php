<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Titillium+Web:wght@400;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Titillium Web', sans-serif;
        }

        img.logo {
            width: 150px;
            height: auto;
            margin-top: 50px;
        }

        .navbar {
            height: 12%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-right: 30px;
        }

        nav ul {
            list-style: none;
            display: flex;
            column-gap: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            transition: ease 0.5s;
        }

        nav ul li a:hover {
            color: #000;
        }

        .container {
            width: 100%;
            height: 100vh;
            padding-left: 8%;
            padding-right: 8%;
            background-image: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
                url(./images/Lovepik_com-500669163-science-and-technology-automobile-background.png);
            background-position: center;
            background-size: cover;
        }

        .row {
            display: flex;
            align-items: center;
            column-gap: 10px;
            height: 88%;
            justify-content: center;
            flex-direction: column;
        }

        .col {
            flex-basis: 50%;
        }

        h1 {
            color: #fff;
            font-size: 70px;
        }

        .cards {
            max-width: 900px;
            margin: auto;
            text-align: center;
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
            justify-content: center;
        }

        .card {
            width: 270px;
            height: 220px;
            border-radius: 10px;
            padding: 5px 20px;
            cursor: pointer;
            background-position: center;
            background-size: cover;
            position: center;
            transition: ease 0.5s;
            margin-bottom: 250px;
        }

        .card:hover {
            transform: translateY(-10px);
        }

        .card .card-head {
            background-color: rgb(0, 0, 0, 0.7);
            color: #fff;
            border-radius: 6px;
            padding: 6px;
            font-size: 16px;
        }

    </style>
</head>

<body>
    <div class="container">
        <div class="navbar">
            <a href="#">
                <img class="logo" src="./images/images.png" alt="logo">
            </a>
            <nav>
                <ul>
                    <li><a href="/proje/Home.php">HOME</a></li>
                    <li><a href="/proje/OurCars.php">OUR CARS</a></li>
                    <li><a href="/proje/About.php">ABOUT</a></li>
                    <li><a href="http://localhost/proje/Contact.php">CONTACT</a></li>
                </ul>
            </nav>
        </div>
        <div class="row">
            <h1>Mercedes-Benz Cars</h1>
            <div class="cards">
                <?php
                $host = "localhost";
                $kullanici = "root";
                $sifre = "1234";
                $veritabani = "carsdb";
                $tablo = "cars";

                $baglanti = mysqli_connect($host, $kullanici, $sifre);

                if ($baglanti) {
                    // Veritabanını seç
                    mysqli_select_db($baglanti, $veritabani) or die("Veri Tabanına Bağlanılamadı");

                    // Belirli URL'lere sahip araç verilerini çek
                    $selectQuery = "SELECT Marka, Model, Yıl, Fiyat, ImageURL FROM $tablo WHERE ImageURL IN ('images/mercedes-1.png', 'images/mercedes-2.png', 'images/mercedes-3.png')";
                    $result = mysqli_query($baglanti, $selectQuery);

                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo '<div class="card card-1" style="background-image: url(' . $row['ImageURL'] . ');">';
                            echo '<div class="card-head">';
                            echo '<h5>' . $row['Marka'] . '</h5>';
                            echo '<p>Model: ' . $row['Model'] . '</p>';
                            echo '<p>Yıl: ' . $row['Yıl'] . '</p>';
                            echo '<p>Fiyat: ' . $row['Fiyat'] . '</p>';
                            echo '</div>';
                            echo '</div>';
                        }
                    } else {
                        echo "Veri çekme hatası: " . mysqli_error($baglanti);
                    }
                } else {
                    echo "Bağlantı Sağlanamadı";
                }
                ?>
            </div>
        </div>
    </div>
</body>

</html>